package com.sabanciuniv.repo;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.sabanciuniv.model.Account;

public interface AccountRepo extends MongoRepository<Account, String>{

}
