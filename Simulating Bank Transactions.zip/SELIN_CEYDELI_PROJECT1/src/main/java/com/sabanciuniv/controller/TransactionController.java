package com.sabanciuniv.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sabanciuniv.model.Account;
import com.sabanciuniv.model.AccountSummary;
import com.sabanciuniv.model.Message;
import com.sabanciuniv.model.Transaction;
import com.sabanciuniv.model.TransactionPayload;
import com.sabanciuniv.repo.AccountRepo;
import com.sabanciuniv.repo.TransactionRepo;

@RestController
@RequestMapping("/transaction")
public class TransactionController {
	
	@Autowired TransactionRepo transactionRepo;
	@Autowired AccountRepo accountRepo;
	
	@PostMapping("/save") 
	public Message<Transaction> saveTransaction(@RequestBody TransactionPayload payload) {
		
		Message<Transaction> msg = new Message<Transaction>();
		
		if (payload.getFromAccountId()==null || payload.getToAccountId()==null || payload.getAmount()==0) {
			msg.setMessage("ERROR:missing fields");
			msg.setData(null);
		}
		
		else if (accountRepo.findById(payload.getFromAccountId()).isPresent()==false || accountRepo.findById(payload.getToAccountId()).isPresent()==false) {
			msg.setMessage("ERROR:account id");
			msg.setData(null);
		}
		
		else {
			Account fromAccount = accountRepo.findById(payload.getFromAccountId()).get();
			Account toAccount = accountRepo.findById(payload.getToAccountId()).get();
			Transaction transactionSaved = new Transaction(fromAccount,toAccount,LocalDateTime.now(),payload.getAmount());
			transactionRepo.save(transactionSaved);
			msg.setMessage("SUCCESS");
			msg.setData(transactionSaved);
		}
		
		return msg;
		
	}
	
	@GetMapping("/to/{accountId}")
	public Message<List<Transaction>> incomingTransactions(@PathVariable String accountId) {
		
		Message<List<Transaction>> msg = new Message<List<Transaction>>();
		
		if (accountRepo.findById(accountId).isPresent()==false) {
			msg.setMessage("ERROR:account doesn't exist!");
			msg.setData(null);
		}
		
		else {
			
			List<Transaction> transactions = transactionRepo.findAll();
			List<Transaction> transactionsIn = new ArrayList<>();
			
			for (Transaction transaction : transactions) {
				
				String toId = transaction.getTo().getId();
				
				if (toId.equals(accountId)) {
					transactionsIn.add(transaction);
				}
				
			}
			
			msg.setMessage("SUCCESS");
			msg.setData(transactionsIn);
			
		}
		
		return msg;
		
	}
	
	@GetMapping("/from/{accountId}")
	public Message<List<Transaction>> outgoingTransactions(@PathVariable String accountId) {
		
		Message<List<Transaction>> msg = new Message<List<Transaction>>();
		
		if (accountRepo.findById(accountId).isPresent()==false) {
			msg.setMessage("ERROR:account doesn't exist!");
			msg.setData(null);
		}
		
		else {
			
			List<Transaction> transactions = transactionRepo.findAll();
			List<Transaction> transactionsOut = new ArrayList<>();
			
			for (Transaction transaction : transactions) {
				
				String fromId = transaction.getFrom().getId();
				
				if (fromId.equals(accountId)) {
					transactionsOut.add(transaction);
				}
		
			}
			
			msg.setMessage("SUCCESS");
			msg.setData(transactionsOut);
			
		}
		
		return msg;
		
	}

}
