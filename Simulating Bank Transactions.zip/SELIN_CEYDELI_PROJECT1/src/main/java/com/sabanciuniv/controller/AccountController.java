package com.sabanciuniv.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sabanciuniv.model.Account;
import com.sabanciuniv.model.AccountSummary;
import com.sabanciuniv.model.Message;
import com.sabanciuniv.model.Transaction;
import com.sabanciuniv.repo.AccountRepo;
import com.sabanciuniv.repo.TransactionRepo;

import jakarta.annotation.PostConstruct;

@RestController
@RequestMapping("/account")
public class AccountController {
	
	@Autowired private AccountRepo accountRepo;
	@Autowired private TransactionRepo transactionRepo;
	
	private static final Logger logger = LoggerFactory.getLogger(AccountController.class);
	
	@PostConstruct
	public void init() {
		
		Account acc1 = new Account("1111","Jack Johns",LocalDateTime.now());
		Account acc2 = new Account("2222","Henry Williams",LocalDateTime.now());
		
		if (accountRepo.count() == 0) {
			accountRepo.save(acc1);
			accountRepo.save(acc2);
		}
		
		if (transactionRepo.count() == 0) {
			Transaction transaction1 = new Transaction(acc1,acc2,LocalDateTime.now(),1500);
			Transaction transaction2 = new Transaction(acc2,acc1,LocalDateTime.now(),2500);	
			transactionRepo.save(transaction1);
			transactionRepo.save(transaction2);
		}
		
		logger.info("All sample data saved!");

	}
	
	@PostMapping("/save") 
	public Message<Account> saveAccount(@RequestBody Account account) {
		
		Message<Account> msg = new Message<Account>();
		
		if (account.getId()==null || account.getOwner()==null) {
			msg.setMessage("ERROR:missing fields");
			msg.setData(null);
		}
		
		else {
			Account accountSaved = new Account(account.getId(),account.getOwner(),LocalDateTime.now());
			accountRepo.save(accountSaved);
			msg.setMessage("SUCCESS");
			msg.setData(accountSaved);
		}
		
		return msg;
		
	}
	
	@GetMapping("/{accountId}")
	public Message<AccountSummary> accountSummary(@PathVariable String accountId) {
		
		Message<AccountSummary> msg = new Message<AccountSummary>();
		
		if (accountRepo.findById(accountId).isPresent()==false) {
			msg.setMessage("ERROR:account doesn't exist!");
			msg.setData(null);
		}
		
		else {
			
			double balance = 0; 
			
			Account account = accountRepo.findById(accountId).get();
			List<Transaction> transactions = transactionRepo.findAll();
			List<Transaction> transactionsOut = new ArrayList<>();
			List<Transaction> transactionsIn = new ArrayList<>();
			
			for (Transaction transaction : transactions) {
				
				String fromId = transaction.getFrom().getId();
				String toId = transaction.getTo().getId();
				
				if (fromId.equals(accountId)) {
					transactionsOut.add(transaction);
					balance -= transaction.getAmount();
				}
				
				if (toId.equals(accountId)) {
					transactionsIn.add(transaction);
					balance += transaction.getAmount();
				}
				
			}
			
			AccountSummary summary = new AccountSummary(accountId,account.getOwner(),account.getCreateDate(),transactionsOut,transactionsIn,balance);
			
			msg.setMessage("SUCCESS");
			msg.setData(summary);
			
		}
		
		return msg;
	
	}

}
